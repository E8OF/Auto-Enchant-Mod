package com.pikavault.ezmacro.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public abstract class Module {
    private final String name;
    private final String description;
    private boolean enabled;
    private int keybind; // GLFW key code, 0 = none

    public Module(String name, String description) {
        this.name = name;
        this.description = description;
        this.enabled = false;
        this.keybind = 0;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public boolean isEnabled() { return enabled; }
    public int getKeybind() { return keybind; }
    public void setKeybind(int key) { this.keybind = key; }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            String status = enabled ? "§aON" : "§cOFF";
            client.player.sendMessage(Text.literal("§d[Pika] §f" + name + " " + status), false);
        }
        if (enabled) onEnable();
        else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient client) {}
}
