package com.pikavault.ezmacro.gui;

import com.pikavault.ezmacro.PikaEzMacroClient;
import com.pikavault.ezmacro.module.AutoEnchantModule;
import com.pikavault.ezmacro.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ClickGuiScreen extends Screen {

    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private long openTime;

    // Panels
    private int panelX = 40;
    private int panelY = 40;
    private final int panelW = 220;
    private final int panelH = 280;

    private Module hoveredModule = null;
    private boolean showAutoEnchantConfig = false;

    // Sub screens
    private AutoEnchantConfigScreen configScreen = null;

    public ClickGuiScreen() {
        super(Text.literal("Pika EZ Macro"));
        openTime = System.currentTimeMillis();
        // spawn initial rain particles
        for (int i = 0; i < 80; i++) {
            particles.add(new Particle(random.nextInt(400), random.nextInt(300), random.nextFloat() * 2 + 1));
        }
    }

    @Override
    protected void init() {
        super.init();
        panelX = 40;
        panelY = 40;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark translucent background
        context.fill(0, 0, this.width, this.height, 0xCC0A0A12);

        // Update & draw neon rain particles
        updateParticles();
        for (Particle p : particles) {
            int alpha = (int) (p.alpha * 255);
            int color = (alpha << 24) | 0x00FF66FF; // neon cyan/magenta mix
            context.fill((int) p.x, (int) p.y, (int) p.x + 2, (int) p.y + 6, color);
            // glow
            context.fill((int) p.x - 1, (int) p.y - 1, (int) p.x + 3, (int) p.y + 7, (alpha / 3 << 24) | 0x00AAFFAA);
        }

        // Main panel background with neon border
        drawNeonPanel(context, panelX, panelY, panelW, panelH);

        // Title
        String title = "§d§lPIKA EZ MACRO";
        context.drawCenteredTextWithShadow(this.textRenderer, title, panelX + panelW / 2, panelY + 10, 0xFF66FF);

        // Modules
        int y = panelY + 32;
        hoveredModule = null;
        for (Module module : PikaEzMacroClient.moduleManager.getModules()) {
            boolean hovered = mouseX >= panelX + 8 && mouseX <= panelX + panelW - 8 &&
                    mouseY >= y && mouseY <= y + 22;

            if (hovered) hoveredModule = module;

            // Module button
            int bg = module.isEnabled() ? 0xAA00FF88 : 0xAA1A1A2E;
            if (hovered) bg = module.isEnabled() ? 0xCC00FFAA : 0xCC2A2A4E;

            context.fill(panelX + 8, y, panelX + panelW - 8, y + 22, bg);

            // neon left bar
            int barColor = module.isEnabled() ? 0xFF00FFAA : 0xFFAA00FF;
            context.fill(panelX + 8, y, panelX + 11, y + 22, barColor);

            String name = (module.isEnabled() ? "§a" : "§7") + module.getName();
            context.drawTextWithShadow(this.textRenderer, name, panelX + 18, y + 7, 0xFFFFFF);

            // right click hint
            if (hovered) {
                context.drawTextWithShadow(this.textRenderer, "§8R-Click", panelX + panelW - 55, y + 7, 0xAAAAAA);
            }

            y += 26;
        }

        // Big footer
        String footer1 = "§d§ldiscord.gg/pikavault";
        String footer2 = "§7Pika EZ Macro for §fHaseeb";
        context.drawCenteredTextWithShadow(this.textRenderer, footer1, this.width / 2, this.height - 28, 0xFF66FF);
        context.drawCenteredTextWithShadow(this.textRenderer, footer2, this.width / 2, this.height - 16, 0xAAAAAA);

        // Glow line under footer
        context.fill(this.width / 2 - 80, this.height - 8, this.width / 2 + 80, this.height - 6, 0x8800FFAA);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawNeonPanel(DrawContext context, int x, int y, int w, int h) {
        // outer glow
        context.fill(x - 3, y - 3, x + w + 3, y + h + 3, 0x3300FFAA);
        context.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x5500FF88);

        // main body
        context.fill(x, y, x + w, y + h, 0xEE0D0D1A);

        // neon border
        int neon = 0xFF00FFAA;
        context.fill(x, y, x + w, y + 2, neon);          // top
        context.fill(x, y + h - 2, x + w, y + h, neon);  // bottom
        context.fill(x, y, x + 2, y + h, neon);          // left
        context.fill(x + w - 2, y, x + w, y + h, neon);  // right
    }

    private void updateParticles() {
        for (Particle p : particles) {
            p.y += p.speed;
            p.alpha = MathHelper.clamp(p.alpha - 0.004f, 0.15f, 1f);
            if (p.y > this.height + 10) {
                p.y = -10;
                p.x = random.nextInt(Math.max(1, this.width));
                p.alpha = 0.6f + random.nextFloat() * 0.4f;
                p.speed = 1.2f + random.nextFloat() * 2.5f;
            }
        }
        // occasionally add more
        if (random.nextInt(8) == 0) {
            particles.add(new Particle(random.nextInt(Math.max(1, this.width)), -5, 1.5f + random.nextFloat() * 2));
            if (particles.size() > 120) particles.remove(0);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (hoveredModule != null) {
            if (button == 0) { // left click = toggle
                hoveredModule.toggle();
                return true;
            }
            if (button == 1) { // right click = open config
                if (hoveredModule instanceof AutoEnchantModule auto) {
                    this.client.setScreen(new AutoEnchantConfigScreen(this, auto));
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // Simple particle
    private static class Particle {
        float x, y, speed, alpha;
        Particle(float x, float y, float speed) {
            this.x = x;
            this.y = y;
            this.speed = speed;
            this.alpha = 0.7f;
        }
    }
}
