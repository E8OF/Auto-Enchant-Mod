package com.pikavault.ezmacro.gui;

import com.pikavault.ezmacro.module.AutoEnchantModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class AutoEnchantConfigScreen extends Screen {

    private final Screen parent;
    private final AutoEnchantModule module;

    private TextFieldWidget searchField;
    private boolean showingItems = true; // true = item list, false = enchant list
    private String search = "";
    private int scroll = 0;

    private final List<Item> allEnchantableItems = new ArrayList<>();
    private final List<RegistryEntry<Enchantment>> allEnchants = new ArrayList<>();

    public AutoEnchantConfigScreen(Screen parent, AutoEnchantModule module) {
        super(Text.literal("Auto Enchant Config"));
        this.parent = parent;
        this.module = module;

        // Collect enchantable items (simplified list of common ones + all tools/armor/weapons)
        allEnchantableItems.addAll(List.of(
                Items.DIAMOND_SWORD, Items.NETHERITE_SWORD, Items.IRON_SWORD, Items.GOLDEN_SWORD, Items.STONE_SWORD, Items.WOODEN_SWORD,
                Items.DIAMOND_PICKAXE, Items.NETHERITE_PICKAXE, Items.IRON_PICKAXE, Items.GOLDEN_PICKAXE, Items.STONE_PICKAXE, Items.WOODEN_PICKAXE,
                Items.DIAMOND_AXE, Items.NETHERITE_AXE, Items.IRON_AXE, Items.GOLDEN_AXE, Items.STONE_AXE, Items.WOODEN_AXE,
                Items.DIAMOND_SHOVEL, Items.NETHERITE_SHOVEL, Items.IRON_SHOVEL,
                Items.DIAMOND_HOE, Items.NETHERITE_HOE,
                Items.BOW, Items.CROSSBOW, Items.TRIDENT, Items.MACE,
                Items.DIAMOND_HELMET, Items.NETHERITE_HELMET, Items.IRON_HELMET, Items.GOLDEN_HELMET, Items.LEATHER_HELMET, Items.CHAINMAIL_HELMET, Items.TURTLE_HELMET,
                Items.DIAMOND_CHESTPLATE, Items.NETHERITE_CHESTPLATE, Items.IRON_CHESTPLATE, Items.GOLDEN_CHESTPLATE, Items.LEATHER_CHESTPLATE, Items.CHAINMAIL_CHESTPLATE,
                Items.DIAMOND_LEGGINGS, Items.NETHERITE_LEGGINGS, Items.IRON_LEGGINGS, Items.GOLDEN_LEGGINGS, Items.LEATHER_LEGGINGS, Items.CHAINMAIL_LEGGINGS,
                Items.DIAMOND_BOOTS, Items.NETHERITE_BOOTS, Items.IRON_BOOTS, Items.GOLDEN_BOOTS, Items.LEATHER_BOOTS, Items.CHAINMAIL_BOOTS,
                Items.SHIELD, Items.FISHING_ROD, Items.SHEARS, Items.FLINT_AND_STEEL, Items.ELYTRA, Items.CARROT_ON_A_STICK, Items.WARPED_FUNGUS_ON_A_STICK
        ));
    }

    @Override
    protected void init() {
        super.init();
        searchField = new TextFieldWidget(this.textRenderer, this.width / 2 - 100, 40, 200, 18, Text.literal("Search..."));
        searchField.setChangedListener(s -> {
            search = s.toLowerCase(Locale.ROOT);
            scroll = 0;
        });
        searchField.setPlaceholder(Text.literal("§7Search items / enchants..."));
        this.addSelectableChild(searchField);
        this.setInitialFocus(searchField);

        // Load all enchantments from registry (done lazily when needed)
        if (this.client != null && this.client.world != null) {
            allEnchants.clear();
            this.client.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT).streamEntries()
                    .forEach(allEnchants::add);
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xDD0A0A12);

        // Header
        context.drawCenteredTextWithShadow(this.textRenderer, "§d§lAUTO ENCHANT CONFIG", this.width / 2, 15, 0xFF66FF);

        // Two big buttons
        drawButton(context, this.width / 2 - 160, 70, 150, 28, showingItems, "§f⚙ Configure Item");
        drawButton(context, this.width / 2 + 10, 70, 150, 28, !showingItems, "§f✦ Enchantments");

        // Current selection info
        String currentItem = "§7Target: §f" + module.targetItem.getName().getString();
        context.drawCenteredTextWithShadow(this.textRenderer, currentItem, this.width / 2, 108, 0xFFFFFF);

        String enchCount = "§7Selected Enchants: §a" + module.selectedEnchants.size();
        context.drawCenteredTextWithShadow(this.textRenderer, enchCount, this.width / 2, 120, 0xFFFFFF);

        // Search
        searchField.render(context, mouseX, mouseY, delta);

        // List
        int listY = 150;
        int listH = this.height - 180;
        context.fill(this.width / 2 - 160, listY, this.width / 2 + 160, listY + listH, 0xAA111122);

        if (showingItems) {
            renderItemList(context, mouseX, mouseY, listY, listH);
        } else {
            renderEnchantList(context, mouseX, mouseY, listY, listH);
        }

        // Footer
        context.drawCenteredTextWithShadow(this.textRenderer, "§ddiscord.gg/pikavault §8| §7Pika EZ Macro for Haseeb", this.width / 2, this.height - 18, 0xAAAAAA);

        // Back hint
        context.drawTextWithShadow(this.textRenderer, "§8ESC to go back", 10, this.height - 18, 0x888888);

        super.render(context, mouseX, mouseY, delta);
    }

    private void drawButton(DrawContext context, int x, int y, int w, int h, boolean active, String text) {
        int bg = active ? 0xCC00FF88 : 0xAA1A1A2E;
        context.fill(x, y, x + w, y + h, bg);
        // neon border
        int border = active ? 0xFF00FFAA : 0xFFAA00FF;
        context.fill(x, y, x + w, y + 1, border);
        context.fill(x, y + h - 1, x + w, y + h, border);
        context.fill(x, y, x + 1, y + h, border);
        context.fill(x + w - 1, y, x + w, y + h, border);
        context.drawCenteredTextWithShadow(this.textRenderer, text, x + w / 2, y + 10, 0xFFFFFF);
    }

    private void renderItemList(DrawContext context, int mouseX, int mouseY, int listY, int listH) {
        List<Item> filtered = allEnchantableItems.stream()
                .filter(i -> i.getName().getString().toLowerCase(Locale.ROOT).contains(search))
                .collect(Collectors.toList());

        int entryH = 18;
        int maxVisible = listH / entryH;
        int start = Math.max(0, Math.min(scroll, Math.max(0, filtered.size() - maxVisible)));

        for (int i = 0; i < maxVisible && start + i < filtered.size(); i++) {
            Item item = filtered.get(start + i);
            int y = listY + 4 + i * entryH;
            boolean selected = item == module.targetItem;
            boolean hovered = mouseX >= this.width / 2 - 150 && mouseX <= this.width / 2 + 150 &&
                    mouseY >= y && mouseY <= y + entryH - 2;

            if (selected) {
                context.fill(this.width / 2 - 152, y - 1, this.width / 2 + 152, y + entryH - 1, 0x6600FF88);
            } else if (hovered) {
                context.fill(this.width / 2 - 152, y - 1, this.width / 2 + 152, y + entryH - 1, 0x33FFFFFF);
            }

            String name = (selected ? "§a▶ " : "§7") + item.getName().getString();
            context.drawTextWithShadow(this.textRenderer, name, this.width / 2 - 145, y + 4, 0xFFFFFF);
        }
    }

    private void renderEnchantList(DrawContext context, int mouseX, int mouseY, int listY, int listH) {
        if (allEnchants.isEmpty() && this.client != null && this.client.world != null) {
            this.client.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT).streamEntries()
                    .forEach(allEnchants::add);
        }

        List<RegistryEntry<Enchantment>> filtered = allEnchants.stream()
                .filter(e -> {
                    String name = Enchantment.getName(e, 1).getString().toLowerCase(Locale.ROOT);
                    return name.contains(search);
                })
                .collect(Collectors.toList());

        int entryH = 18;
        int maxVisible = listH / entryH;
        int start = Math.max(0, Math.min(scroll, Math.max(0, filtered.size() - maxVisible)));

        for (int i = 0; i < maxVisible && start + i < filtered.size(); i++) {
            RegistryEntry<Enchantment> entry = filtered.get(start + i);
            int y = listY + 4 + i * entryH;
            boolean selected = module.isEnchantSelected(entry);
            boolean hovered = mouseX >= this.width / 2 - 150 && mouseX <= this.width / 2 + 150 &&
                    mouseY >= y && mouseY <= y + entryH - 2;

            if (selected) {
                context.fill(this.width / 2 - 152, y - 1, this.width / 2 + 152, y + entryH - 1, 0x6600FF88);
            } else if (hovered) {
                context.fill(this.width / 2 - 152, y - 1, this.width / 2 + 152, y + entryH - 1, 0x33FFFFFF);
            }

            String name = Enchantment.getName(entry, 1).getString();
            String prefix = selected ? "§a✔ " : "§7○ ";
            context.drawTextWithShadow(this.textRenderer, prefix + name, this.width / 2 - 145, y + 4, 0xFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // Tab buttons
        if (mouseY >= 70 && mouseY <= 98) {
            if (mouseX >= this.width / 2.0 - 160 && mouseX <= this.width / 2.0 - 10) {
                showingItems = true;
                scroll = 0;
                return true;
            }
            if (mouseX >= this.width / 2.0 + 10 && mouseX <= this.width / 2.0 + 160) {
                showingItems = false;
                scroll = 0;
                return true;
            }
        }

        // List clicks
        int listY = 150;
        int listH = this.height - 180;
        int entryH = 18;
        int maxVisible = listH / entryH;

        if (mouseY >= listY && mouseY <= listY + listH) {
            int index = (int) ((mouseY - listY - 4) / entryH) + scroll;
            if (showingItems) {
                List<Item> filtered = allEnchantableItems.stream()
                        .filter(i -> i.getName().getString().toLowerCase(Locale.ROOT).contains(search))
                        .collect(Collectors.toList());
                if (index >= 0 && index < filtered.size()) {
                    module.setTargetItem(filtered.get(index));
                    return true;
                }
            } else {
                if (allEnchants.isEmpty() && this.client != null && this.client.world != null) {
                    this.client.world.getRegistryManager().get(RegistryKeys.ENCHANTMENT).streamEntries()
                            .forEach(allEnchants::add);
                }
                List<RegistryEntry<Enchantment>> filtered = allEnchants.stream()
                        .filter(e -> Enchantment.getName(e, 1).getString().toLowerCase(Locale.ROOT).contains(search))
                        .collect(Collectors.toList());
                if (index >= 0 && index < filtered.size()) {
                    module.toggleEnchant(filtered.get(index));
                    return true;
                }
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, scroll - (int) verticalAmount);
        return true;
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
