package com.pikavault.ezmacro.util;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    public static void drawNeonRect(DrawContext context, int x, int y, int w, int h, int color, int glowColor) {
        // outer glow
        context.fill(x - 2, y - 2, x + w + 2, y + h + 2, glowColor);
        // main
        context.fill(x, y, x + w, y + h, color);
    }

    public static void drawHorizontalLine(DrawContext context, int x1, int x2, int y, int color) {
        context.fill(x1, y, x2, y + 1, color);
    }
}
