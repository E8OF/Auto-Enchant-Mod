package com.pikavault.ezmacro;

import com.pikavault.ezmacro.gui.ClickGuiScreen;
import com.pikavault.ezmacro.module.AutoEnchantModule;
import com.pikavault.ezmacro.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class PikaEzMacroClient implements ClientModInitializer {

    public static final String MOD_ID = "pikaezmacro";
    public static KeyBinding openGuiKey;
    public static ModuleManager moduleManager;

    @Override
    public void onInitializeClient() {
        moduleManager = new ModuleManager();
        moduleManager.register(new AutoEnchantModule());

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.pikaezmacro.opengui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.pikaezmacro"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            moduleManager.onTick(client);
        });

        System.out.println("[Pika EZ Macro] Loaded for Haseeb | discord.gg/pikavault");
    }
}
