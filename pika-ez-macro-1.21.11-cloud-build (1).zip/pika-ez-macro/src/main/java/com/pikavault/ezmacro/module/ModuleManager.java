package com.pikavault.ezmacro.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public Module getModuleByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    public void onTick(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        for (Module module : modules) {
            if (module.getKeybind() != 0) {
                if (InputUtil.isKeyPressed(window, module.getKeybind()) &&
                    !InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_RIGHT_SHIFT)) {
                    // simple edge detection would be better, but this works for now
                }
            }
            if (module.isEnabled()) {
                module.onTick(client);
            }
        }
    }
}
