# Pika EZ Macro

Client-side Fabric mod for Minecraft **1.21.11**. Requires Java 21 and Fabric API for Minecraft 1.21.11.

## Build without installing Gradle on your PC

This project includes a GitHub Actions workflow that builds the mod on GitHub's hosted runner.

1. Upload this project to a GitHub repository (or push it to a repository you own).
2. Open the repository's **Actions** tab.
3. Select **Build Fabric Mod** and click **Run workflow** (or push to `main` / `master`).
4. When the run finishes, open it and download the artifact named `pika-ez-macro-1.21.11`.
5. Inside the downloaded artifact, use the mod JAR in your `.minecraft/mods` folder with Fabric Loader and Fabric API for **1.21.11**.

## Controls
- **Right Shift**: open the GUI
- Left-click a module: toggle it
- Right-click Auto Enchant: open its configuration

## Important
The source targets Minecraft 1.21.11, Yarn `1.21.11+build.3`, Fabric Loader `0.18.2`, and Fabric API `0.140.0+1.21.11`. This source has not been compiled in this environment because outbound network access to Gradle/Maven hosts is unavailable, so the cloud build must be checked for any remaining compiler errors before using the JAR.
